=== Kama Breadcrumbs ===

Stable tag:        trunk
Tested up to:      5.3.2
Requires at least: 3.0
Requires PHP:      5.4
License:           GPLv2 or later
License URI:       http://www.gnu.org/licenses/gpl-2.0.html
Contributors:      Kama
Tags:              breabcrumbs

Smart Breabcrumbs for WordPress site.



== Description ==

New, fourth version-simpler, more stable, extensible and understandable code. Modified hook system. Additional functionality. The absence of some bugs.


== FAQ ==






== TODO ==




== Changelog ==

### 4.8.6.2
 - Fix: Default parameters were passing wrong when call `do_action( 'echo_kama_breadcrumbs' );`

### 4.8.6.1
 - Fix: sometimes you could see pagination for page 404.

### 4.8.6
 - Fix: the parameter for exclude taxes for display is changed from `public` to `publicly_queryable`. Now, when register taxonomy, only `publicly_queryable=false` will exclude the taxonomy from show list.

### 4.8.5
 - Fix: Bug when two parameters were passed to hook: `do_action( 'echo_kama_breadcrumbs', $args, $l10n )`.

### 4.8.4
 - New: filter hook `disable_kama_breadcrumbs`. Allows completely disable breadcrumbs.
 - New: action hook `echo_kama_breadcrumbs`. Use `do_action('echo_kama_breadcrumbs')` in theme to show breadcrumbs and leave ability to disable this show: `remove_action( 'echo_kama_breadcrumbs', 'echo_kama_breadcrumbs' );`.

### 4.8.3
 - New: Добавил возможность включить старый формат маркировки. Укажите в параметр `markup = data-vocabulary.org`.
 - New: Добавил class атрибут для ссылковых элементов крошек (иногда может пригодится).

### 4.8.2
 - Chg: Min PHP version 5.4.
 - Chg: Minor code changes.

### 4.8.1
 - Fix: Archive foir month translarion string fix.

### 4.8.0
 - Fix: relative URL not allowed in <meta> parameter

### 4.7.8
 - Fix: Последний элемент на типах страниц 404, search не оборачивался в теги.

### 4.7.7
 - FIX: Убрал микроразметку для последнего элемента крошек, когда там заголовок без ссылки (для крошке нужна ссылка иначе микроразметка невалидная).

### 4.7.6
 - BUG: Не выводился заголовок на пустой странице рахива типа записей (если там не было записей).

### 4.7.5
 - BUG: Был неоформленный в нужный тег заголовок (последний элемент) для архива типа записи.

### 4.7.4
 - NEW: Параметр `use_the_title_filter` - позволяет включить обработку всех заголовков записей через фильтр `the_title`.

### 4.7.3
 - NEW: Если в ЧПУ указаны термины, то они будут учитываться при подсчете приоритетных такс. Например было: запись находится в двух терминах и в ЧПУ показан один термин, а в крошках другой. Теперь крошки в этом случае зависят от ЧПУ (только если приоритетный термин не указан вручную).

### 4.7.2
 - Замена функции esc_html(). Теперь HTML код в тексте крошки будет удален. Например, было: "Главная > Заголовок &lt;span&gt;страницы&lt;/span&gt;", стало: "Главная > Заголовок страницы"

### 4.7.1
 - NEW: Добавлена обработка ошибки в структуре древовидных таксономий или записей, когда у одного из элементов цепочки крошек установлен ID родителя, а этот родитель является дочерним элементом. Это вызывает беконечное зацикливание! В этом случае плагин показывает ошибку уровня 'PHP notice', при этом крошки создаются, но они неправильные.

### 4.7
 - NEW: пареметр 'number_tax' - позволяет выводить в крошках для записей сразу несколько таксономий. Пример: array('post'=>2) - для типа записи post выведет крошки для двух таксономий (по умолчанию: category и post_tag). Поменять порядок также можно в параметре 'priority_tax'.
 - NEW: хук: 'kama_breadcrumbs_terms' аналог 'kama_breadcrumbs_term' только получает все определившиеся термины таксономий (нужен для параметра 'number_tax').
 - BUG: выводилась ссылка сама на себя, при просмотре неприкрепленного вложения.
 - BUG: когда в крошках не было элементов, выводился просто разделитель. Теперь в этом случае выводится HTML комментарий `&lt;!-- no elements for breadcrumbs --&gt;`
 - УЛУЧШЕНИЕ: в параметре '$elms' фильтра 'kama_breadcrumbs_filter_elements' можно указывать бесконечно вложенные массивы. Это удобно когда добавляешь свои элементы крошек, до этого из-за путаницы с массивами добавляемый элемент иногда выглядел как 'array'...
 - NEW: перевод строк на англ. (en_US).
 - ВНИМАНИЕ: изменились ключи массива получаемого через хук 'kama_breadcrumbs_filter_elements' - ключи типов 'tax_crumbs' и 'page_crumbs', если вы их использовали в коде, то код придется обновить (упростить), извините за неудобства! В 99% случаев проблем при обновлении быть не должно!
 - ВНИМАНИЕ: второй параметр передаваемый хуками: 'attachment_tax_crumbs' и 'post_tax_crumbs' теперь содержит массив с объектами '$terms', а не сам объект '$term'. Если вы использовали эти хуки, возможно придется обновить код. В 99% случаев проблем при обновлении быть не должно!

### 4.6
 - NEW: Параметры: 'wrap_class', 'title_class', 'sep_class'.

### 4.5
 - NEW: `kama_breadcrumbs()` возвращает результат, а не выводит на экран.

### 4.4
 - Изменены фильтры: kama_breadcrumbs_default_loc > kama_breadcrumbs_l10n и kama_breadcrumbs_default_args > kama_breadcrumbs_args.

### 4.3
 - Параметр 'title_patt' удален и теперь он идет в комплекте с микроразметкой 'titlepatt'.
 - Доработана микроразметка: добавлен тип schema.org - RDFa. Добавлена обработка элемента ORDERNUM. Немного изменена логика.
 - Удален основной параметр функции '$sep'. Теперь он указывается в массиве '$args'. Изменен порядок параметров при вызове функции.

### 4.2
 - Параметр 'priority_terms' удален и теперь он работает в параметре 'priority_tax'.
 - Новый параметр 'disable_tax'.

### 4.1
 - Доработана проверка приоритетных терминов, чтобы учитывались родители терминов при проверке.

### 4.0
 - Новая логика сбора крошек - теперь все собирается в массив а не строку. Это упрощает код и дает больше возможностей управления крошками.
 - удалены хуки 'kama_breadcrumbs_home_after', 'kama_breadcrumbs_pre_out' из заменяет новый хук 'kama_breadcrumbs_filter_elements'

### 3.3
 - Новые хуки: attachment_tax_crumbs, post_tax_crumbs, term_tax_crumbs. Позволяют дополнить крошки таксономий.

### 3.2
 - Баг с разделителем, с отключенным 'show_term_title'. Стабилизировал логику.

### 3.1
 - Баг с esc_html() для заголовка терминов - с тегами получалось криво...

### 3.0
 - Обернул в класс. Добавил опции: 'title_patt', 'last_sep'. Доработал код. Добавил пагинацию для постов.

### 2.5
 - ADD: Опция 'show_term_title'

### 2.4
 - Мелкие правки кода

### 2.3
 - ADD: Страница записей, когда для главной установлена отделенная страница.

### 2.2
 - ADD: Link to post type archive on taxonomies page

### 2.1
 - ADD: $sep, $loc, $args params to hooks

### 2.0
 - ADD: в фильтр 'kama_breadcrumbs_home_after' добавлен четвертый аргумент $ptype

### 1.9
 - ADD: фильтр 'kama_breadcrumbs_l10n' для изменения локализации по умолчанию

### 1.8
 - FIX: заметки, когда в рубрике нет записей

### 1.7
 - Улучшена работа с приоритетными таксономиями.

