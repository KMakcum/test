<?php
/*
 * Plugin Name: Solution Factory Import-Export Addon
 * Description:
 * Version: 2.0.0
 * Author: SolutionFactory Team
 * Author URI: https://solutionfactory.ru/
 * Text Domain: solution_factory_import
 */
