<?php
/*
 * Plugin Name: LifeChef Telegram bot
 * Description: use TB::m( $message );
 * Version: 1.0.6
 * Author: LifeChef Team
 * Text Domain: sf_tg
 */

if ( !class_exists( 'TB' ) ) {

    /**
     * Class TB.
     */
    class TB {

        /**
         * @var array
         */
        private static $time_start = [];

        /**
         * @var array
         */
        private static $message = [];

        /**
         * Start time.
         *
         * @param  string $type
         * @return void
         */
        public static function start( $type = 'default' ) {
            self::$time_start[$type] = microtime( true );
        }

        /**
         * Add text to message.
         *
         * @param  string $message
         * @param  string $type
         * @return void
         */
        public static function add_message( $message, $type = 'default' ) {
            self::$message[$type] .= $message;
        }

        /**
         * Return message var.
         *
         * @param  string $type
         * @return string
         */
        public static function get_message( $type = 'default' ) {
            return self::$message[$type];
        }

        /**
         * Show message.
         *
         * @param bool $time_mark
         * @param  string $type
         * @return void
         */
        public static function show_message( $time_mark = false, $type = 'default' ) {
            self::m( self::$message[$type], $time_mark, $type );
        }

        /**
         * Return delta time.
         *
         * @param  string $type
         * @return float
         */
        public static function get_time( $type = 'default' ) {
            return microtime( true ) - self::$time_start[$type];
        }

        /**
         * Telegram bot send message method.
         *
         * @param mixed $message
         * @param bool $time_mark
         * @param  string $type
         * @return void
         */
        public static function m( $message, $time_mark = false, $type = 'default' ) {
            if ( !defined( 'TG_TOKEN' ) OR !defined( 'TG_CHAT_ID' ) ) {
                return;
            }

            if ( is_array( $message ) OR is_object( $message ) ) {
                $message = print_r( $message, true );
            }

            if ( $time_mark ) {
                $time = round( self::get_time( $type ), 5 );
                $type_text = '';
                if ( $type != 'default' ) {
                    $type_text = " '$type'";
                    $type_text = str_replace( '_', '-', $type_text );
                }
                $message = "_rt{$type_text}: $time sec._\n $message";
            }

            $ch = curl_init();
            curl_setopt_array(
                $ch,
                array(
                    CURLOPT_URL => 'https://api.telegram.org/bot' . TG_TOKEN . '/sendMessage',
                    CURLOPT_POST => TRUE,
                    CURLOPT_RETURNTRANSFER => TRUE,
                    CURLOPT_TIMEOUT => 1,
                    CURLOPT_POSTFIELDS => array(
                        'chat_id' => TG_CHAT_ID,
                        'text' => $message,
                        'parse_mode' => 'Markdown',
                        'disable_web_page_preview' => 'true',
                        'disable_notification' => 'true',
                    ),
                )
            );
            curl_exec( $ch );
        }
    }
}