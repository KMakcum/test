<?php

/*
 * Plugin Name: Solution Factory Variations Addon for Meals
 * Description: 
 * Version: 1.1.42
 * Author: SolutionFactory Team
 * Author URI: https://solutionfactory.ru/
 */